const entries = performance.getEntriesByType("navigation");

console.log("tasks-scripts loaded")

if (entries.length > 0) {
    const navType = entries[0].entryType;
    console.log(navType);

    if (navType === "reload") {
        console.log("This page was refreshed!");
    } else if (navType === "navigate") {
        console.log("This is the first load (user typed URL or clicked a link).");
    } else if (navType === "back_forward") {
        console.log("User arrived here via back or forward button.");
    }
}